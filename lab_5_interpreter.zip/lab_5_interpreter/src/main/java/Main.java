package phones;

import java.awt.Color;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        FindPhone finder = new FindPhone();

        // Использование нового метода
        List<Phone> results = finder.byModelAndPriceLowAndColor("nokii", 13000, Color.PINK);

        // Вывод результатов
        System.out.println("Found " + results.size() + " phones:");
        for (Phone phone : results) {
            System.out.println(
                    phone.getModel() + " | " +
                            phone.getPrice() + " | " +
                            phone.getColor() + " | " +
                            phone.getMemorySize() + "GB"
            );
        }
    }
}