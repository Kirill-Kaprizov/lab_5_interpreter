package phones;

import java.awt.Color;
import java.util.LinkedList;
import java.util.List;

public class FindPhone {
    private List<Phone> data;

    public FindPhone() {
        this.data = new PhoneDB().getPhoneData();
    }

    public List<Phone> byColor(Color col) {
        List<Phone> result = new LinkedList<>();
        if (data == null) return result;

        for (Phone ph : data) {
            if (ph.getColor().equals(col)) {
                result.add(ph);
            }
        }
        return result;
    }

    public List<Phone> byModel(String mod) {
        List<Phone> result = new LinkedList<>();
        if (data == null) return result;

        for (Phone ph : data) {
            if (ph.getModel().equalsIgnoreCase(mod)) {
                result.add(ph);
            }
        }
        return result;
    }

    public List<Phone> byMSize(int memSize) {
        List<Phone> result = new LinkedList<>();
        if (data == null) return result;

        for (Phone ph : data) {
            if (ph.getMemorySize() == memSize) {
                result.add(ph);
            }
        }
        return result;
    }

    public List<Phone> byModelAndPriceLow(String mod, double price) {
        List<Phone> result = new LinkedList<>();
        if (data == null) return result;

        for (Phone ph : data) {
            if (ph.getModel().equalsIgnoreCase(mod) && ph.getPrice() < price) {
                result.add(ph);
            }
        }
        return result;
    }

    public List<Phone> byMSizeAndNotColor(int memSize, Color col) {
        List<Phone> result = new LinkedList<>();
        if (data == null) return result;

        for (Phone ph : data) {
            if (ph.getMemorySize() == memSize && !ph.getColor().equals(col)) {
                result.add(ph);
            }
        }
        return result;
    }

    public List<Phone> byModelAndPriceLowAndColor(String nokii, int i, Color pink) {
        return null;
    }
}