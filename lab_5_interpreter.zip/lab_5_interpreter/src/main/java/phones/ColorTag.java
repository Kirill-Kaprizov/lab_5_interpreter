package phones;

import java.awt.*;

public abstract class ColorTag extends Tag {
    private final Color color;

    public ColorTag(Color color) {
        this.color = color;
    }

    @Override
    public boolean find(Phone ph) {
        return ph.getColor().equals(color);
    }
}