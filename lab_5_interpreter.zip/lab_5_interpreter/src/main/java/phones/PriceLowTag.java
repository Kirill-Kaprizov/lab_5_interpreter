package phones;

public abstract class PriceLowTag extends Tag {
    private final double maxPrice;

    public PriceLowTag(double maxPrice) {
        this.maxPrice = maxPrice;
    }

    @Override
    public boolean find(Phone ph) {
        return ph.getPrice() <= maxPrice;
    }
}