package phones;

public abstract class Tag {
    public abstract boolean interpret(Phone phone);

    public abstract boolean find(Phone ph);
}